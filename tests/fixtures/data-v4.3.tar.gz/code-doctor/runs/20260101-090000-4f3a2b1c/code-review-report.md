# Code review

One finding.
